<div class="pull-right mt-2 mb-5 d-none d-sm-block">
    {{ $alltuitions->links() }}
</div>

<div class="pull-right mt-2 mb-5 d-block d-sm-none">
    {{-- {{ $alltuitions->links('vendor.pagination.simple-bootstrap-4') }} --}}
</div>
